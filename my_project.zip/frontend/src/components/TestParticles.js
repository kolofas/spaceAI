import React from 'react';
import Particles from 'react-tsparticles';

function TestParticles() {
    return (
        <div style={{
            position: 'relative',
            height: '100vh',
            width: '100vw',
            backgroundColor: '#000',
        }}>
            <Particles
                options={{
                    background: {
                        color: {
                            value: "#000",
                        },
                    },
                    particles: {
                        number: {
                            value: 100,
                        },
                        size: {
                            value: 3,
                        },
                        move: {
                            enable: true,
                            speed: 1,
                        },
                    },
                }}
            />
        </div>
    );
}

export default TestParticles;
