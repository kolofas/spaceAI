// src/components/Profile.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
    const [userData, setUserData] = useState(null);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const refreshAccessToken = async () => {
        try {
            const refreshToken = localStorage.getItem('refreshToken');
            const response = await axios.post('http://127.0.0.1:8000/api/token/refresh/', {
                refresh: refreshToken,
            });
            localStorage.setItem('accessToken', response.data.access);
            return response.data.access;
        } catch (err) {
            setError('Session expired. Please log in again.');
            localStorage.removeItem('accessToken');
            localStorage.removeItem('refreshToken');
            navigate('/login');
            return null;
        }
    };

    const fetchUserData = async () => {
        let token = localStorage.getItem('accessToken');
        if (!token) {
            navigate('/login');
            return;
        }

        try {
            const response = await axios.get('http://127.0.0.1:8000/api/profile/', {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            setUserData(response.data);
        } catch (err) {
            if (err.response?.status === 401) {
                token = await refreshAccessToken();
                if (token) {
                    fetchUserData(); // Повторить запрос с обновлённым токеном
                }
            } else {
                setError('Failed to fetch user data. Please log in again.');
            }
        }
    };

    useEffect(() => {
        fetchUserData();
    }, []);

    if (error) {
        return <p className="text-danger">{error}</p>;
    }

    if (!userData) {
        return <p>Loading...</p>;
    }

    return (
        <div className="container mt-5">
            <h2>Profile</h2>
            <p><strong>Username:</strong> {userData.username}</p>
            <p><strong>Email:</strong> {userData.email}</p>
        </div>
    );
};

export default Profile;
