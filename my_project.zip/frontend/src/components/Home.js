import React from 'react';
import Particles from "react-tsparticles";

function Home() {
    return (
        <div style={{
            position: 'relative',
            minHeight: '100vh',
            width: '100%',
            fontFamily: 'Arial, sans-serif',
            textAlign: 'center',
            color: '#fff',
            backgroundColor: '#121212',  // Темный фон на весь экран
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            flexDirection: 'column',
            overflow: 'hidden',  // Убираем горизонтальную и вертикальную прокрутку
        }}>
            {/* Анимация частиц на весь экран */}
            <Particles
                style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    zIndex: -1,  // Частицы должны быть на заднем фоне
                }}
                options={{
                    particles: {
                        number: {
                            value: 150, // Увеличиваем количество частиц для более плотного фона
                            density: {
                                enable: true,
                                value_area: 800
                            }
                        },
                        size: {
                            value: 5,  // Увеличиваем размер частиц для более заметных эффектов
                            random: true
                        },
                        move: {
                            enable: true,
                            speed: 1,  // Увеличиваем скорость движения частиц
                            direction: "none",
                            random: true,
                            straight: false
                        },
                        opacity: {
                            value: 0.5,
                            random: true
                        }
                    },
                    interactivity: {
                        events: {
                            onhover: {
                                enable: true,
                                mode: "repulse"  // Режим отталкивания при наведении
                            }
                        }
                    }
                }}
            />

            {/* Контент страницы */}
            <div style={{
                position: 'relative',
                zIndex: 1,
                maxWidth: '100%',
                padding: '0 20px',
            }}>
                <h1 style={{ fontSize: '4rem', fontWeight: 'bold', marginBottom: '1rem' }}>
                    Welcome to StarnetAI
                </h1>
                <p style={{ fontSize: '1.5rem', marginBottom: '2rem', maxWidth: '700px', margin: '0 auto' }}>
                    Your trusted platform for managing categories, networks, and reviews.
                </p>

                {/* Кнопки */}
                <div style={{
                    display: 'flex',
                    justifyContent: 'center',
                    gap: '20px',
                    marginTop: '20px'
                }}>
                    <button
                        style={{
                            padding: '15px 30px',
                            fontSize: '1.2rem',
                            color: '#fff',
                            background: 'linear-gradient(135deg, #ff9800, #ff5722)',
                            border: 'none',
                            borderRadius: '30px',
                            cursor: 'pointer',
                            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
                            transition: 'transform 0.2s, box-shadow 0.2s',
                        }}
                    >
                        Get Started
                    </button>
                    <button
                        style={{
                            padding: '15px 30px',
                            fontSize: '1.2rem',
                            color: '#fff',
                            background: 'linear-gradient(135deg, #2196f3, #3f51b5)',
                            border: 'none',
                            borderRadius: '30px',
                            cursor: 'pointer',
                            boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
                            transition: 'transform 0.2s, box-shadow 0.2s',
                        }}
                    >
                        Learn More
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Home;
